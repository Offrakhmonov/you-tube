# youtube-downloader-bot
pyTelegramBotAPI va pytube yordamida YouTubedan video va audiolarni yuklovchi Telegram Bot ochiq kodlari

## Yuklanishi kerak bo'lgan paketlar

- pyTelegramBotAPI
- pytube

## Foydalanish

1) config.py fayl ichiga TOKEN joylang
2) ```python3 bot.py``` run qilish kerak

### Dasturchi

- [Turdibek Jumabev](https://github.com/turdibek-jumabaev)